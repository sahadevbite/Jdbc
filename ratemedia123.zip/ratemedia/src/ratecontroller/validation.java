package ratecontroller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoImp.RateService;
import daoImp.RateServiceImp;


/**
 *
 * @author Administrator
 */
@WebServlet(name = "checkAdmin", urlPatterns = {"/checkAdmin"})
public class validation extends HttpServlet {
	
	
	RateService rateImpl = new RateServiceImp();
	private static final long serialVersionUID = 1453069247241116723L;


	public void init(ServletConfig config) throws ServletException {
    	
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String gender=request.getParameter("gender");
        String bday=request.getParameter("bday");
       
        try {
        	
        	
        	rateImpl.RegisterUser(username, password,name,email,gender,bday, null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	response.sendRedirect("/ratemedia/user.jsp");
        
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    

}
