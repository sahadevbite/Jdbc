package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Database
{
	public static Connection getConnection() throws Exception
	{
		try
		{
			String connectionURL = "jdbc:mysql://10.254.172.154:3306/ratemedia";
			Connection connection = null;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager.getConnection(connectionURL, "basit", "abc@1234");
			
			return connection;
		} catch (Exception e)
		{
			throw e;
		}
		
	}

}
