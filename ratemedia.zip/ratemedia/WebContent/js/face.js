function bigImg(x)
{
x.style.height="107px";
x.style.width="107px";
}

function normalImg(x)
{
x.style.height="102px";
x.style.width="102px";
}
