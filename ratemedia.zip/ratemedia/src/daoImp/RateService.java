package daoImp;

import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;

import bean.UserBean;

public interface RateService {

   public void RegisterUser(String username, String password, String name, String email, String gender, String bday, InputStream inputStream) throws SQLException;

   public String loginuser(String username, String password) throws SQLException;

   public String getFlag(String username);

   public int getAdmindata(String username, String password);

   public List<UserBean> CheckPendingReq(String username);

   public int updateUser(String id, String name);

    public List<UserBean> CheckSubmit();

	

   
   
}
