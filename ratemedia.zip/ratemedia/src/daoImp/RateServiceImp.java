package daoImp;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.UserBean;
import dao.Database;

public class RateServiceImp implements RateService {
	
	private static Connection con = null;
	private Statement stmt = null;
	private static ResultSet rs = null;
    String  message =null;

	@Override
	public void RegisterUser(String username, String password, String name, String email, String gender, String bday,InputStream inputStream) throws SQLException {
		try {
			con = Database.getConnection();
		
		stmt = con.createStatement();
		
	  String sql = "INSERT INTO user (name, email,birthday,password,username,gender,save_flag,photo) values ( ?, ?,?,?,?,?,?,?)";
         PreparedStatement statement = con.prepareStatement(sql);
         statement.setString(1, name);
         statement.setString(2, email);
         statement.setString(3, bday);
         statement.setString(4, password);
         statement.setString(5, username);
         statement.setString(6, gender);
         statement.setString(7, "N");
         if (inputStream != null) {
             // fetches input stream of the upload file for the blob column
             statement.setBlob(8, inputStream);
             
         }
         int row = statement.executeUpdate();

         if (row > 0) {
             message = "Data saved into database";
            
         }
         } catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		} 
         finally{
			 if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
		}

		
	}
	}

	@SuppressWarnings("finally")
	@Override
	public String loginuser(String username, String password) throws SQLException {
		String data ="";
		try {
			con = Database.getConnection();
		
		stmt = con.createStatement();
		String query = "select * from user where username = '" + username +"' and password ='"+password+"'";
	      rs = stmt.executeQuery(query);
	      
	      while(rs.next()){	        
	          data = rs.getString("name");
	          String email = rs.getString("email"); 
	      }
	      
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			 if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
		}

		return data;
	}
	}

	@SuppressWarnings("finally")
	@Override
	public String getFlag(String username) {
		
		String flag ="";
		try {
			con = Database.getConnection();
		
		stmt = con.createStatement();
		String query = "select save_flag from user where username = '" + username +"'";
	      rs = stmt.executeQuery(query);
	      
	      while(rs.next()){	        
	          flag = rs.getString("save_flag");
	      }
	      
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			 if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
		}

		return flag;
	}
	}

	@SuppressWarnings("finally")
	@Override
	public int getAdmindata(String username, String password) {
		
		int recordExistOrNot = 0;

		try {
			con = Database.getConnection();
		
		stmt = con.createStatement();
		String query = "select * from autherization where username = '" + username +"' and role = 'admin'";
	      rs = stmt.executeQuery(query);
	      
	      while(rs.next()){	        
	    	  recordExistOrNot = rs.getRow();
	      }
	      
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			 if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
		}

		return recordExistOrNot;
	}
	}

	@Override
	public List<UserBean> CheckPendingReq(String username) {
		
		List<UserBean> data = new ArrayList<UserBean>();
		
		UserBean user = null;
		try {
			con = Database.getConnection();
		
		stmt = con.createStatement();
		String query = "select * from user where save_flag = 'N'";
	      rs = stmt.executeQuery(query);
	      
	      while(rs.next()){	        
	    	  user = new UserBean();
	    	  user.setId(rs.getInt("id"));
	    	  user.setName(rs.getString("name"));
	    	  user.setBirthday(rs.getString("birthday"));
	    	  user.setEmail(rs.getString("email"));
	    	  user.setGender((rs.getString("gender")));
	    	  user.setFlag((rs.getString("save_flag")));
	    	  data.add(user);
	      }
	      
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			 if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
		}

		}
		return data;
	}

	@SuppressWarnings("finally")
	@Override
	public int updateUser(String id, String name) {
		 int row =0;
		try {
			con = Database.getConnection();
		
		stmt = con.createStatement();
		
	  String sql = "UPDATE user set save_flag ='Y' where id="+id+" and name ='"+name+"'";
         PreparedStatement statement = con.prepareStatement(sql);
          row = statement.executeUpdate();

         if (row > 0) {
             message = "Data saved into database";
            
         }
         } catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		} 
         finally{
			 if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
		}

		return row;
	}
	}

	@Override
	public List<UserBean> CheckSubmit() {
		
List<UserBean> data = new ArrayList<UserBean>();
		
		UserBean user = null;
		try {
			con = Database.getConnection();
		
		stmt = con.createStatement();
		String query = "select * from user where save_flag = 'Y'";
	      rs = stmt.executeQuery(query);
	      
	      while(rs.next()){	        
	    	  user = new UserBean();
	    	  user.setId(rs.getInt("id"));
	    	  user.setName(rs.getString("name"));
	    	  user.setBirthday(rs.getString("birthday"));
	    	  user.setEmail(rs.getString("email"));
	    	  user.setGender((rs.getString("gender")));
	    	  user.setFlag((rs.getString("save_flag")));
	    	  data.add(user);
	      }
	      
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			 if (con != null) {
	                try {
	                    con.close();
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                }
		}

		}
		return data;
	}

	
}
