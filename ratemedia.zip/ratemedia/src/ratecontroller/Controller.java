package ratecontroller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import daoImp.RateService;
import daoImp.RateServiceImp;


/**
 *
 * @author Administrator
 */
@WebServlet(name = "Controller", urlPatterns = {"/Controller"})
public class Controller extends HttpServlet {
	
	
	RateService rateImpl = new RateServiceImp();
	private static final long serialVersionUID = 1453069247241116723L;


	public void init(ServletConfig config) throws ServletException {
    	
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String gender=request.getParameter("gender");
        String bday=request.getParameter("bday");
        InputStream inputStream = null;
        Part photo = request.getPart("photo");
        if (photo != null) {
            // prints out some information for debugging
            System.out.println(photo.getName());
            System.out.println(photo.getSize());
            System.out.println(photo.getContentType());
             
            // obtains input stream of the upload file
            inputStream = photo.getInputStream();

        }
       
        try {
        	
        	
          	rateImpl.RegisterUser(username, password,name,email,gender,bday,inputStream);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	response.sendRedirect("/ratemedia/user.jsp");
        
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    

}
