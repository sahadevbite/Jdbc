package ratecontroller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;
import daoImp.RateService;
import daoImp.RateServiceImp;


/**
 *
 * @author Administrator
 */
@WebServlet("/approveReq")
public class ApproveReq extends HttpServlet {
	
	
	RateService rateImpl = new RateServiceImp();
	private static final long serialVersionUID = 1453069247241116723L;


	public void init(ServletConfig config) throws ServletException {
    	
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	int data=0;
    	List<UserBean> Reqdata = null;
    	Map<String, Object> model = new HashMap<String, Object>();
    	String flag ="";
        String id=request.getParameter("id");
        String name=request.getParameter("name");
       
       data = rateImpl.updateUser(id, name);
        if(data > 0){
        	 
             request.getRequestDispatcher("/adminlanding.jsp").forward(request, response);

        }else{
             request.setAttribute("data", data); 
            request.getRequestDispatcher("/user.jsp").forward(request, response);
        }
        
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
