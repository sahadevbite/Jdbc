package ratecontroller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoImp.RateService;
import daoImp.RateServiceImp;


/**
 *
 * @author Administrator
 */
@WebServlet(name = "useraction", urlPatterns = {"/useraction"})
public class User extends HttpServlet {
	
	
	RateService rateImpl = new RateServiceImp();
	private static final long serialVersionUID = 1453069247241116723L;


	public void init(ServletConfig config) throws ServletException {
    	
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String data=null;
    	String flag ="";
        String username=request.getParameter("username");
        String password=request.getParameter("password");
       
       try {
		data = rateImpl.loginuser(username, password);
	} catch (SQLException e) {
		e.printStackTrace();
	}
        if(data!=""){
        	
        	 flag = rateImpl.getFlag(username);
        	 request.setAttribute("flag", flag); 
             request.getRequestDispatcher("/landinguser.jsp").forward(request, response);

        }else{
        	data ="fail";
             request.setAttribute("data", data); 
            request.getRequestDispatcher("/user.jsp").forward(request, response);
        }
        
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
